# Atividade videoaula flexbox

A Pen created on CodePen.

Original URL: [https://codepen.io/Krisley-Lopes/pen/jEWKZNQ](https://codepen.io/Krisley-Lopes/pen/jEWKZNQ).

